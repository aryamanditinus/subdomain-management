<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate the subdomain input
    $subdomain = filter_var(trim($_POST['subdomain']), FILTER_SANITIZE_SPECIAL_CHARS);

    if (empty($subdomain)) {
        echo "Subdomain cannot be empty.";
        exit();
    }

    if (!preg_match('/^[a-zA-Z0-9-]+$/', $subdomain)) {
        echo "Invalid subdomain name. Only letters, numbers, and hyphens are allowed.";
        exit();
    }

    if (strpos($subdomain, '.') !== false) {
        echo "Subdomain name should not contain a period.";
        exit();
    }

    // Create the subdomain directory
    $subdomainDir = "/var/www/test-subdomains/{$subdomain}";
    if (!is_dir($subdomainDir)) {
        mkdir($subdomainDir, 0755, true);
        file_put_contents("{$subdomainDir}/index.html", "<h1>Welcome to {$subdomain}.mytestings.site</h1>");
    }

    // Restart Apache to apply changes (optional, not needed with wildcard config)
    // shell_exec('sudo systemctl reload apache2');

    echo "Subdomain {$subdomain}.mytestings.site created successfully.";
}
?>
