#!/bin/bash

DOMAIN=$1

# Create verification directory structure
sudo mkdir -p "/var/www/verifications/$DOMAIN/.well-known/acme-challenge"
sudo chown -R www-data:www-data "/var/www/verifications/$DOMAIN"
sudo chmod -R 755 "/var/www/verifications/$DOMAIN"
