#!/bin/bash
DOMAIN=$1
TARGET=$2

# Check A record
if ! dig +short $DOMAIN | grep -q '3.109.139.57'; then
    echo "A record verification failed for $DOMAIN"
    exit 1
fi

# Check CNAME
if ! dig +short www.$DOMAIN CNAME | grep -q "$TARGET.mytestings.site"; then
    echo "CNAME verification failed for www.$DOMAIN"
    exit 1
fi

echo "DNS records verified successfully for $DOMAIN"
exit 0
