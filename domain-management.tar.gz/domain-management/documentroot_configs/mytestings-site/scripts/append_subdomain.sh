#!/bin/bash

# Get the subdomain configuration from the argument
SUBDOMAIN_CONFIG="$1"

# Path to the main Apache configuration file
APACHE_CONFIG="/etc/apache2/sites-available/mytestings.site.conf"

echo -e "\n# Subdomain Configuration\n$SUBDOMAIN_CONFIG" >> "$APACHE_CONFIG"

echo "Subdomain configuration appended."
