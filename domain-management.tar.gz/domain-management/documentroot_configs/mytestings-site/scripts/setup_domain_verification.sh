#!/bin/bash
DOMAIN=$1
TOKEN=$2

# Debug output
echo "=== Starting domain setup for: $DOMAIN ==="

# Create Apache config
echo "Creating Apache config..."
sudo tee /etc/apache2/sites-available/$DOMAIN.conf > /dev/null <<EOL
<VirtualHost *:80>
    ServerName $DOMAIN
    DocumentRoot /var/www/verifications/$DOMAIN
    ErrorLog \${APACHE_LOG_DIR}/$DOMAIN-error.log
    CustomLog \${APACHE_LOG_DIR}/$DOMAIN-access.log combined
</VirtualHost>
EOL

# Enable site
echo "Enabling site..."
sudo a2ensite $DOMAIN.conf

# Reload Apache
echo "Reloading Apache..."
sudo systemctl reload apache2

echo "=== Script completed successfully ==="
