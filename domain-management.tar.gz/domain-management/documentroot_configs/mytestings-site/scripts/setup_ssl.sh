#!/bin/bash

DOMAIN=$1

# First create verification directories
sudo -u www-data /var/www/mytestings-site/scripts/setup_verification_dirs.sh "$DOMAIN"

# Then run Certbot
certbot certonly --webroot -w "/var/www/verifications/$DOMAIN" \
  -d "$DOMAIN" \
  -d "www.$DOMAIN" \
  --non-interactive \
  --agree-tos \
  --email admin@mytestings.site

# Rest of your SSL setup logic...
