#!/bin/bash
set -e

DOMAIN="$1"
TARGET_SUBDOMAIN="$2"
TEMPLATE_HTTP="/etc/apache2/sites-available/custom-domain-http.conf"
TEMPLATE_HTTPS="/etc/apache2/sites-available/custom-domain-https.conf"
CONF_HTTP="/etc/apache2/sites-available/${DOMAIN}.conf"
CONF_HTTPS="/etc/apache2/sites-available/${DOMAIN}-ssl.conf"

# Create verification directory
sudo mkdir -p "/var/www/verifications/${DOMAIN}/.well-known/acme-challenge"
sudo chown -R www-data:www-data "/var/www/verifications/${DOMAIN}"
sudo chmod -R 755 "/var/www/verifications/${DOMAIN}"

# Step 1: Create HTTP config
sudo cp "$TEMPLATE_HTTP" "$CONF_HTTP"
sudo sed -i "s/{DOMAIN}/${DOMAIN}/g" "$CONF_HTTP"
sudo a2ensite "$(basename "$CONF_HTTP" .conf)"
sudo systemctl reload apache2

# Step 2: Obtain SSL certificate
sudo certbot certonly --webroot -w "/var/www/verifications/${DOMAIN}" \
    -d "${DOMAIN}" \
    -d "www.${DOMAIN}" \
    --non-interactive \
    --agree-tos \
    --email admin@mytestings.site \
    --force-renewal

# Step 3: Create HTTPS config
sudo cp "$TEMPLATE_HTTPS" "$CONF_HTTPS"
sudo sed -i "s/{DOMAIN}/${DOMAIN}/g" "$CONF_HTTPS"
sudo sed -i "s/{TARGET_SUBDOMAIN}/${TARGET_SUBDOMAIN}/g" "$CONF_HTTPS"
sudo a2ensite "$(basename "$CONF_HTTPS" .conf)"
sudo systemctl reload apache2

echo "Proxy configuration completed for ${DOMAIN} → ${TARGET_SUBDOMAIN}.mytestings.site"
