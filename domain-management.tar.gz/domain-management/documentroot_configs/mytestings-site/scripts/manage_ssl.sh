#!/bin/bash
set -e

DOMAIN="$1"
SSL_TYPE="$2"

LE_CERT_DIR="/etc/letsencrypt/live/$DOMAIN"
CUSTOM_CERT_DIR="/etc/ssl/custom-certs/$DOMAIN"

case "$SSL_TYPE" in
    letsencrypt)
        # Obtain certificate using webroot authentication
        sudo certbot certonly --webroot -w "/var/www/verifications/$DOMAIN" \
            -d "$DOMAIN" -d "www.$DOMAIN" \
            --non-interactive \
            --agree-tos \
            --email admin@mytestings.site \
            --force-renewal
        
        # Update Apache SSL configuration
        sudo sed -i "s|SSLCertificateFile.*|SSLCertificateFile $LE_CERT_DIR/fullchain.pem|" \
            "/etc/apache2/sites-available/$DOMAIN.conf"
        sudo sed -i "s|SSLCertificateKeyFile.*|SSLCertificateKeyFile $LE_CERT_DIR/privkey.pem|" \
            "/etc/apache2/sites-available/$DOMAIN.conf"
        ;;
        
    custom)
        # Move uploaded files to custom cert directory
        sudo mkdir -p "$CUSTOM_CERT_DIR"
        sudo mv /tmp/ssl_temp.* "$CUSTOM_CERT_DIR/"
        
        # Update Apache SSL configuration
        sudo sed -i "s|SSLCertificateFile.*|SSLCertificateFile $CUSTOM_CERT_DIR/fullchain.pem|" \
            "/etc/apache2/sites-available/$DOMAIN.conf"
        sudo sed -i "s|SSLCertificateKeyFile.*|SSLCertificateKeyFile $CUSTOM_CERT_DIR/privkey.key|" \
            "/etc/apache2/sites-available/$DOMAIN.conf"
        ;;
esac

# Reload Apache
sudo systemctl reload apache2
echo "SSL configured successfully for $DOMAIN ($SSL_TYPE)"
