#!/bin/bash
for DOMAIN in /etc/letsencrypt/live/*; do
    DOMAIN=$(basename $DOMAIN)
    if [ "$DOMAIN" != "README" ]; then
        sed -i \
            -e "s|SSLCertificateFile.*|SSLCertificateFile /etc/letsencrypt/live/${DOMAIN}/fullchain.pem|" \
            -e "s|SSLCertificateKeyFile.*|SSLCertificateKeyFile /etc/letsencrypt/live/${DOMAIN}/privkey.pem|" \
            "/etc/apache2/sites-available/${DOMAIN}.conf"
    fi
done
systemctl reload apache2
