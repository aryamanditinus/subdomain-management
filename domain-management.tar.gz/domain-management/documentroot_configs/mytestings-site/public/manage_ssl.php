<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

try {
    $domain = filter_input(INPUT_POST, 'domain', FILTER_SANITIZE_STRING);
    $sslType = filter_input(INPUT_POST, 'ssl_type', FILTER_SANITIZE_STRING);
    $userId = $_SESSION['user_id'];

    // Validate domain ownership
    $stmt = $pdo->prepare("SELECT id FROM custom_domains WHERE custom_domain = ? AND user_id = ?");
    $stmt->execute([$domain, $userId]);
    if (!$stmt->fetch()) throw new Exception("Invalid domain");

    // Handle file uploads for custom SSL
    if ($sslType === 'custom') {
        $certFile = handleUploadedFile('ssl_cert', "/tmp/ssl_temp.crt");
        $keyFile = handleUploadedFile('ssl_key', "/tmp/ssl_temp.key");
        $chainFile = handleUploadedFile('ssl_chain', "/tmp/ssl_temp.chain");
    }

    // Execute SSL management script
    $output = shell_exec("sudo /var/www/mytestings-site/scripts/manage_ssl.sh " .
        escapeshellarg($domain) . " " .
        escapeshellarg($sslType) . " 2>&1");

    if (strpos($output, 'successfully') === false) {
        throw new Exception("SSL setup failed: " . $output);
    }

    $_SESSION['success'] = "SSL configuration updated successfully!";
} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
}

header("Location: dashboard.php");

function handleUploadedFile($field, $tempPath) {
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("Missing required SSL file: $field");
    }
    move_uploaded_file($_FILES[$field]['tmp_name'], $tempPath);
    return $tempPath;
}
