<?php
header('Content-Type: application/json');
require __DIR__ . '/../config/db.php';

$domain = filter_var($_GET['domain'], FILTER_SANITIZE_STRING);
$valid = false;

// Check A record
$aRecords = dns_get_record($domain, DNS_A);
if (!empty($aRecords)) {
    require __DIR__ . '/../config/public_ip.php';
    $valid = $aRecords[0]['ip'] === PUBLIC_IP;
}

// Check CNAME
if (!$valid) {
    $cnameRecords = dns_get_record("www.$domain", DNS_CNAME);
    $valid = !empty($cnameRecords) && 
        $cnameRecords[0]['target'] === 'your-subdomain.mytestings.site';
}

echo json_encode(['valid' => $valid]);
