<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $subdomain = trim($_POST['subdomain']);
        $userId = $_SESSION['user_id'];

        // Validate input
        if (empty($subdomain)) {
            throw new Exception("Subdomain cannot be empty");
        }

        if (!preg_match('/^[a-z0-9-]+$/i', $subdomain)) {
            throw new Exception("Only letters, numbers, and hyphens allowed");
        }

        // Check existing subdomain
        $stmt = $pdo->prepare("SELECT id FROM subdomains WHERE subdomain_name = ?");
        $stmt->execute([$subdomain]);
        if ($stmt->fetch()) {
            throw new Exception("Subdomain already exists");
        }

        // Create directory
        $dirPath = "/var/www/test-subdomains/$subdomain";
        if (!is_dir($dirPath)) {
            if (!mkdir($dirPath, 0755, true)) {
                throw new Exception("Failed to create directory");
            }
            file_put_contents("$dirPath/index.html", "<h1>Welcome to $subdomain.mytestings.site</h1>");
        }

        // Database insertion
        $stmt = $pdo->prepare("INSERT INTO subdomains (user_id, subdomain_name) VALUES (?, ?)");
        if (!$stmt->execute([$userId, $subdomain])) {
            throw new Exception("Database insertion failed: " . implode(" ", $stmt->errorInfo()));
        }

        $_SESSION['success'] = "Subdomain created successfully!";
        header('Location: dashboard.php');
        exit();

    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        header('Location: dashboard.php');
        exit();
    }
}
?>
