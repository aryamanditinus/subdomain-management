<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

require __DIR__ . '/../config/db.php';
require __DIR__ . '/../includes/auth.php';

try {
    if (!isset($_SESSION['user_id'])) throw new Exception("Unauthorized access");
    if (!isset($_POST['domain'])) throw new Exception("Domain parameter missing");

    $domain = filter_var($_POST['domain'], FILTER_SANITIZE_SPECIAL_CHARS);
    $userId = $_SESSION['user_id'];

    // Get subdomain details
    $stmt = $pdo->prepare("SELECT s.subdomain_name FROM custom_domains c
        JOIN subdomains s ON c.subdomain_id = s.id 
        WHERE c.custom_domain=? AND c.user_id=?");
    $stmt->execute([$domain, $userId]);
    $subdomain = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$subdomain) {
        throw new Exception("Domain not found in database");
    }

    /***********************
     * DNS Verification
     ***********************/
    $dnsOutput = shell_exec("sudo /var/www/mytestings-site/scripts/verify_domain.sh " .
        escapeshellarg($domain) . " " .
        escapeshellarg($subdomain['subdomain_name']) . " 2>&1");

    if (strpos($dnsOutput, "verified") === false) {
        error_log("DNS verification failed for $domain. Output: $dnsOutput");
        throw new Exception("DNS verification failed. Please check:<br>" . 
            htmlspecialchars($dnsOutput));
    }

    /***********************
     * Proxy Setup
     ***********************/
    $proxyOutput = shell_exec("sudo /var/www/mytestings-site/scripts/setup_proxy.sh " .
        escapeshellarg($domain) . " " .
        escapeshellarg($subdomain['subdomain_name']) . " 2>&1");

    if (strpos($proxyOutput, "created for") === false) {
        error_log("Proxy setup failed for $domain. Output: $proxyOutput");
        throw new Exception("Proxy configuration failed");
    }

    /***********************
     * SSL Setup
     ***********************/
    $ssl_type = $_POST['ssl_type'] ?? 'letsencrypt';
    $sslOutput = shell_exec("sudo /var/www/mytestings-site/scripts/setup_ssl.sh " .
        escapeshellarg($domain) . " " .
        escapeshellarg($ssl_type) . " 2>&1");

    if (strpos($sslOutput, "Certificate is saved at") === false) {
        error_log("SSL setup failed for $domain. Output: $sslOutput");
        throw new Exception("SSL configuration failed ..");
    }

    /***********************
     * Database Update
     ***********************/
    $updated = $pdo->prepare("UPDATE custom_domains SET is_verified=1 WHERE custom_domain=?")
        ->execute([$domain]);

    if (!$updated) {
        throw new Exception("Database update failed");
    }

    $_SESSION['success'] = "✅ Domain $domain successfully verified and configured!";
    
} catch (Exception $e) {
    $_SESSION['error'] = "❌ Error: " . $e->getMessage();
    error_log("Domain verification error: " . $e->getMessage());
}

header("Location: dashboard.php");
exit();
