<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/public_ip.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$currentIp = PUBLIC_IP;

try {
    // Fetch user details
    $userStmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $userStmt->execute([$userId]);
    $user = $userStmt->fetch(PDO::FETCH_ASSOC);

    // Fetch subdomains
    $subdomainStmt = $pdo->prepare("SELECT * FROM subdomains WHERE user_id = ?");
    $subdomainStmt->execute([$userId]);
    $subdomains = $subdomainStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch custom domains with SSL info
    $customDomainStmt = $pdo->prepare("
        SELECT c.*, s.subdomain_name 
        FROM custom_domains c
        JOIN subdomains s ON c.subdomain_id = s.id
        WHERE c.user_id = ?
    ");
    $customDomainStmt->execute([$userId]);
    $customDomains = $customDomainStmt->fetchAll(PDO::FETCH_ASSOC);

    // Process SSL information
    foreach ($customDomains as &$domain) {
        if ($domain['is_verified'] && $domain['ssl_type'] === 'letsencrypt') {
            $certFile = "/etc/letsencrypt/live/{$domain['custom_domain']}/fullchain.pem";
            if (file_exists($certFile)) {
                $certData = openssl_x509_parse(file_get_contents($certFile));
                if ($certData) {
                    $domain['ssl_expiry'] = $certData['validTo_time_t'] ?? null;
                    $domain['ssl_issuer'] = $certData['issuer']['O'] ?? 'Unknown';
                }
            }
        }
    }
    unset($domain);

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - MyTestings.Site</title>
    <link rel="stylesheet" href="/css/styles.css">
    <style>
        .domain-card { margin: 20px 0; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
        .status-badge { padding: 5px 10px; border-radius: 4px; display: inline-block; }
        .verified { background: #d4edda; color: #155724; }
        .pending { background: #fff3cd; color: #856404; }
        .dns-records { margin: 15px 0; padding: 10px; background: #f8f9fa; }
        .dns-record { font-family: monospace; padding: 5px; margin: 5px 0; }
        .verification-section { margin-top: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Welcome, <?= htmlspecialchars($user['username'] ?? 'User') ?></h1>
            <a href="/logout.php" style="float: right;">Logout</a>
            <div style="clear: both;"></div>
        </header>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?= $_SESSION['error'] ?>
                <button type="button" class="close" onclick="this.parentElement.remove()">&times;</button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success'] ?>
                <button type="button" class="close" onclick="this.parentElement.remove()">&times;</button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <!-- Subdomain Creation -->
        <section class="section">
            <h2>Create New Subdomain</h2>
            <form action="create_subdomain.php" method="POST">
                <input type="text" name="subdomain" placeholder="subdomain-name" required 
                       pattern="[a-zA-Z0-9-]+" title="Letters, numbers, and hyphens only">
                <button type="submit">Create Subdomain</button>
            </form>
        </section>

        <!-- Existing Subdomains -->
        <section class="section">
            <h2>Your Subdomains</h2>
            <?php if (!empty($subdomains)): ?>
                <?php foreach ($subdomains as $sub): ?>
                    <div class="domain-card">
                        <h3><?= htmlspecialchars($sub['subdomain_name']) ?>.mytestings.site</h3>
                        <form method="POST" action="setup_custom_domain.php">
                            <input type="hidden" name="subdomain_id" value="<?= $sub['id'] ?>">
                            <input type="text" name="custom_domain" placeholder="yourdomain.com" required>
                            <button type="submit">Attach Custom Domain</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No subdomains created yet.</p>
            <?php endif; ?>
        </section>

        <!-- Custom Domains -->
        <section class="section">
            <h2>Custom Domains</h2>
            <?php if (!empty($customDomains)): ?>
                <?php foreach ($customDomains as $domain): ?>
                    <div class="domain-card">
                        <div class="domain-header">
                            <h3><?= htmlspecialchars($domain['custom_domain']) ?></h3>
                            <span class="status-badge <?= $domain['is_verified'] ? 'verified' : 'pending' ?>">
                                <?= $domain['is_verified'] ? 'Verified' : 'Pending Verification' ?>
                            </span>
                        </div>

                        <?php if (!$domain['is_verified']): ?>
                            <div class="verification-section">
                                <div class="dns-records">
                                    <h4>DNS Configuration Required:</h4>
                                    <div class="dns-record">
                                        A Record: <?= htmlspecialchars($domain['custom_domain']) ?> → <?= $currentIp ?>
                                    </div>
                                    <div class="dns-record">
                                        CNAME: www.<?= htmlspecialchars($domain['custom_domain']) ?> → 
                                        <?= htmlspecialchars($domain['subdomain_name']) ?>.mytestings.site
                                    </div>
                                </div>
                                <form method="POST" action="verify_domain.php">
                                    <input type="hidden" name="domain" 
                                           value="<?= htmlspecialchars($domain['custom_domain']) ?>">
                                    <button type="submit">Verify Configuration</button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="ssl-section">
                                <?php if (isset($domain['ssl_expiry'])): ?>
                                    <div class="ssl-info">
                                        <p>SSL Issuer: <?= htmlspecialchars($domain['ssl_issuer']) ?></p>
                                        <p>Expires: <?= date('Y-m-d', $domain['ssl_expiry']) ?></p>
                                    </div>
                                <?php endif; ?>
                                
                                <form method="POST" action="manage_ssl.php" enctype="multipart/form-data">
                                    <input type="hidden" name="domain" 
                                           value="<?= htmlspecialchars($domain['custom_domain']) ?>">
                                    
                                    <div class="ssl-option">
                                        <label>
                                            <input type="radio" name="ssl_type" value="letsencrypt" 
                                                <?= ($domain['ssl_type'] ?? 'letsencrypt') === 'letsencrypt' ? 'checked' : '' ?>>
                                            Let's Encrypt
                                        </label>
                                    </div>
                                    
                                    <div class="ssl-option">
                                        <label>
                                            <input type="radio" name="ssl_type" value="custom"
                                                <?= ($domain['ssl_type'] ?? '') === 'custom' ? 'checked' : '' ?>>
                                            Custom Certificate
                                        </label>
                                        <div class="cert-fields">
                                            <input type="file" name="ssl_cert" accept=".crt,.pem">
                                            <input type="file" name="ssl_key" accept=".key">
                                        </div>
                                    </div>
                                    
                                    <button type="submit">Update SSL</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No custom domains configured yet.</p>
            <?php endif; ?>
        </section>
    </div>

    <script>
    document.querySelectorAll('input[name="ssl_type"]').forEach(radio => {
        radio.addEventListener('change', function() {
            const certFields = this.closest('.ssl-option').querySelector('.cert-fields');
            certFields.style.display = this.value === 'custom' ? 'block' : 'none';
        });
    });
    </script>
</body>
</html>
