<?php

$public_ip = '3.109.139.57'; // Static setting (recommended for stability)


define('PUBLIC_IP', $public_ip);

#### another ip change in this file: "./scripts/verify_domain.sh"
