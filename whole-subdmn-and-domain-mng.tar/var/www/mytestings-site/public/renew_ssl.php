<?php
require __DIR__ . '/../config/db.php';
require __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

try {
    $domain = filter_input(INPUT_POST, 'domain', FILTER_SANITIZE_STRING);
    $userId = $_SESSION['user_id'];
    
    // Validate ownership
    $stmt = $pdo->prepare("SELECT id FROM custom_domains WHERE custom_domain=? AND user_id=?");
    $stmt->execute([$domain, $userId]);
    if (!$stmt->fetch()) throw new Exception("Domain not found");
    
    // Renew certificate
    $output = shell_exec("sudo certbot renew --cert-name $domain --quiet 2>&1");
    
    if (strpos($output, 'Congratulations') === false) {
        throw new Exception("Renewal failed: " . $output);
    }
    
    $_SESSION['success'] = "Certificate renewed successfully!";
} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
}
header("Location: dashboard.php");
