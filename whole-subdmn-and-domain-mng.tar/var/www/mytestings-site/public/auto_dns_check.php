<?php
require __DIR__ . '/../config/db.php';

$pdo->query("UPDATE custom_domains SET dns_valid=0");

$stmt = $pdo->query("SELECT * FROM custom_domains WHERE is_verified=1");
while ($domain = $stmt->fetch()) {
    $valid = false;
    
    // Check A record
    $aRecords = dns_get_record($domain['custom_domain'], DNS_A);
    if (!empty($aRecords)) {
        $valid = ($aRecords[0]['ip'] === $_SERVER['SERVER_ADDR']);
    }
    
    // Check CNAME
    if (!$valid) {
        $cnameRecords = dns_get_record("www.".$domain['custom_domain'], DNS_CNAME);
        $valid = !empty($cnameRecords) && 
            (strpos($cnameRecords[0]['target'], '.mytestings.site') !== false);
    }
    
    $update = $pdo->prepare("UPDATE custom_domains SET dns_valid=? WHERE id=?");
    $update->execute([$valid ? 1 : 0, $domain['id']]);
}
