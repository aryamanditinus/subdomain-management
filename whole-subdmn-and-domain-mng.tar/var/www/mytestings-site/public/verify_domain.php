<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

require __DIR__ . '/../config/db.php';
require __DIR__ . '/../includes/auth.php';

try {
    if (!isset($_SESSION['user_id'])) throw new Exception("Unauthorized");
    if (!isset($_POST['domain'])) throw new Exception("Domain required");

    $domain = filter_var($_POST['domain'], FILTER_SANITIZE_SPECIAL_CHARS);
    $userId = $_SESSION['user_id'];

    // Get subdomain details
    $stmt = $pdo->prepare("SELECT s.subdomain_name FROM custom_domains c
        JOIN subdomains s ON c.subdomain_id = s.id 
        WHERE c.custom_domain=? AND c.user_id=?");
    $stmt->execute([$domain, $userId]);
    $subdomain = $stmt->fetch(PDO::FETCH_ASSOC) or throw new Exception("Invalid domain");

    // Verify DNS records
    $output = shell_exec("sudo /var/www/mytestings-site/scripts/verify_domain.sh " .
        escapeshellarg($domain) . " " . 
        escapeshellarg($subdomain['subdomain_name']) . " 2>&1");

    if (strpos($output, "verified") === false) {
        throw new Exception("DNS verification failed: " . $output);
    }

    // Create proxy config
    $proxy_output = shell_exec("sudo /var/www/mytestings-site/scripts/setup_proxy.sh " .
        escapeshellarg($domain) . " " . 
        escapeshellarg($subdomain['subdomain_name']) . " 2>&1");

    // Update database
    $pdo->prepare("UPDATE custom_domains SET is_verified=1 WHERE custom_domain=?")
        ->execute([$domain]);

    // SSL Setup
    $ssl_type = $_POST['ssl_type'] ?? 'letsencrypt';
    $ssl_output = shell_exec("sudo /var/www/mytestings-site/scripts/setup_ssl.sh " .
        escapeshellarg($domain) . " " . 
        escapeshellarg($ssl_type) . " 2>&1");

    $_SESSION['success'] = "Domain verified and SSL configured!";

} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
}
header("Location: dashboard.php");
