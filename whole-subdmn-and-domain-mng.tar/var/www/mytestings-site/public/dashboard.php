<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/public_ip.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

try {
    // Fetch user details
    $userStmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $userStmt->execute([$userId]);
    $user = $userStmt->fetch(PDO::FETCH_ASSOC);

    // Fetch subdomains
    $subdomainStmt = $pdo->prepare("SELECT * FROM subdomains WHERE user_id = ?");
    $subdomainStmt->execute([$userId]);
    $subdomains = $subdomainStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch custom domains with SSL info
    $customDomainStmt = $pdo->prepare("
        SELECT c.*, s.subdomain_name 
        FROM custom_domains c
        JOIN subdomains s ON c.subdomain_id = s.id
        WHERE c.user_id = ?
    ");
    $customDomainStmt->execute([$userId]);
    $customDomains = $customDomainStmt->fetchAll(PDO::FETCH_ASSOC);

    // Process SSL expiry dates
    foreach ($customDomains as &$domain) {
        if ($domain['is_verified'] && $domain['ssl_type'] === 'letsencrypt') {
            $cert_file = "/etc/letsencrypt/live/{$domain['custom_domain']}/fullchain.pem";
            if (file_exists($cert_file)) {
                $cert_data = openssl_x509_parse(file_get_contents($cert_file));
                $domain['ssl_expiry'] = $cert_data['validTo_time_t'] ?? null;
            }
        }
    }
    unset($domain);

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .section { margin: 20px 0; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
        .domain-card { margin: 10px 0; padding: 15px; border: 1px solid #eee; }
        .verified { color: #28a745; }
        .pending { color: #dc3545; }
        .dns-instructions { background: #f8f9fa; padding: 15px; margin-top: 10px; }
        .dns-record { padding: 8px; margin: 5px 0; background: #fff; border: 1px solid #dee2e6; border-radius: 4px; font-family: monospace; }
        .dns-type { display: inline-block; width: 80px; font-weight: bold; }
        .check-dns-btn { background: #17a2b8; color: white; padding: 6px 12px; border-radius: 4px; border: none; cursor: pointer; }
        .status-indicator { margin-left: 10px; font-weight: bold; }
        .valid { color: #28a745; }
        .invalid { color: #dc3545; }
        .checking { color: #ffc107; }
        .ssl-configuration { margin-top: 20px; padding: 15px; border-top: 1px solid #eee; }
        .ssl-options { display: flex; gap: 20px; flex-wrap: wrap; }
        .ssl-renew { background: #e9ecef; padding: 10px; border-radius: 4px; }
        .custom-cert-fields { margin-top: 10px; display: flex; flex-direction: column; gap: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Welcome, <?= htmlspecialchars($user['username']) ?></h1>
            <a href="/logout.php" style="float: right;">Logout</a>
            <div style="clear: both;"></div>
        </header>

        <!-- Subdomain Creation Section -->
        <section class="section">
            <h2>Create New Subdomain</h2>
            <form action="create_subdomain.php" method="POST">
                <input type="text" name="subdomain" placeholder="subdomain-name" required 
                    pattern="[a-zA-Z0-9-]+" title="Letters, numbers, and hyphens only">
                <button type="submit">Create Subdomain</button>
            </form>
        </section>

        <!-- Existing Subdomains Section -->
        <section class="section">
            <h2>Your Subdomains</h2>
            <?php if (!empty($subdomains)) : ?>
                <?php foreach ($subdomains as $sub) : ?>
                    <div class="domain-card">
                        <h3><?= htmlspecialchars($sub['subdomain_name']) ?>.mytestings.site</h3>
                        <form method="POST" action="setup_custom_domain.php">
                            <input type="hidden" name="subdomain_id" value="<?= $sub['id'] ?>">
                            <input type="text" name="custom_domain" placeholder="yourdomain.com" required>
                            <button type="submit">Attach Custom Domain</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <p>No subdomains created yet.</p>
            <?php endif; ?>
        </section>

        <!-- Custom Domains Section -->
        <section class="section">
            <h2>Custom Domains</h2>
            <?php if (!empty($customDomains)) : ?>
                <?php foreach ($customDomains as $domain) : ?>
                    <div class="domain-card">
                        <h3><?= htmlspecialchars($domain['custom_domain']) ?></h3>
                        <p class="<?= $domain['is_verified'] ? 'verified' : 'pending' ?>">
                            Status: <?= $domain['is_verified'] ? 'Verified' : 'Pending Verification' ?>
                        </p>

                        <?php if (!$domain['is_verified']) : ?>
                            <div class="dns-instructions">
                                <h4>DNS Configuration Required</h4>
                                <p>Add these records to your DNS:</p>
                                
                                <div class="dns-record">
                                    <span class="dns-type">A</span>
                                    <?= htmlspecialchars($domain['custom_domain']) ?> → <?= PUBLIC_IP ?>
                                </div>
                                
                                <div class="dns-record">
                                    <span class="dns-type">CNAME</span>
                                    www.<?= htmlspecialchars($domain['custom_domain']) ?> → 
                                    <?= htmlspecialchars($domain['subdomain_name']) ?>.mytestings.site
                                </div>

                                <form method="POST" action="verify_domain.php">
                                    <input type="hidden" name="domain" 
                                        value="<?= htmlspecialchars($domain['custom_domain']) ?>">
                                    <button type="submit">Verify Configuration</button>
                                </form>
                            </div>
                        <?php else : ?>
                            <div class="dns-instructions">
                                <h4>DNS Configuration</h4>
                                <div class="dns-record">
                                    <span class="dns-type">CNAME</span>
                                    www.<?= htmlspecialchars($domain['custom_domain']) ?> → 
                                    <?= htmlspecialchars($domain['subdomain_name']) ?>.mytestings.site
                                </div>
                                <div class="dns-record">
                                    <span class="dns-type">A Record</span>
                                    <?= htmlspecialchars($domain['custom_domain']) ?> → <?= PUBLIC_IP ?>
                                </div>
                            </div>

                            <div class="ssl-configuration">
                                <h4>SSL/TLS Settings</h4>
                                <div class="ssl-options">
                                    <div class="ssl-renew">
                                        <?php if(isset($domain['ssl_expiry'])) : ?>
                                            Expires: <?= date('Y-m-d', $domain['ssl_expiry']) ?>
                                        <?php else : ?>
                                            Expiration: Not Available
                                        <?php endif; ?>
                                        
                                        <?php if(($domain['ssl_type'] ?? '') === 'letsencrypt') : ?>
                                            <form method="POST" action="/renew_ssl.php">
                                                <input type="hidden" name="domain" 
                                                    value="<?= htmlspecialchars($domain['custom_domain']) ?>">
                                                <button type="submit">Renew Certificate</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="ssl-actions">
                                        <form method="POST" action="configure_ssl.php" enctype="multipart/form-data">
                                            <input type="hidden" name="domain" 
                                                value="<?= htmlspecialchars($domain['custom_domain']) ?>">
                                            
                                            <div class="ssl-choice">
                                                <input type="radio" id="le_<?= $domain['id'] ?>" 
                                                    name="ssl_type" value="letsencrypt" 
                                                    <?= ($domain['ssl_type'] ?? '') === 'letsencrypt' ? 'checked' : '' ?>>
                                                <label for="le_<?= $domain['id'] ?>">Let's Encrypt (Auto-renew)</label>
                                            </div>
                                            
                                            <div class="ssl-choice">
                                                <input type="radio" id="custom_<?= $domain['id'] ?>" 
                                                    name="ssl_type" value="custom"
                                                    <?= ($domain['ssl_type'] ?? '') === 'custom' ? 'checked' : '' ?>>
                                                <label for="custom_<?= $domain['id'] ?>">Custom Certificate</label>
                                                
                                                <div class="custom-cert-fields">
                                                    <div>
                                                        <label>Certificate File (.crt/.pem):</label>
                                                        <input type="file" name="ssl_cert" accept=".crt,.pem">
                                                    </div>
                                                    <div>
                                                        <label>Private Key (.key):</label>
                                                        <input type="file" name="ssl_key" accept=".key">
                                                    </div>
                                                    <div>
                                                        <label>Certificate Chain (optional):</label>
                                                        <input type="file" name="ssl_chain" accept=".crt,.pem">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <button type="submit">Update SSL Settings</button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div style="margin-top: 15px;">
                                <button class="check-dns-btn" 
                                    onclick="checkDNS('<?= $domain['id'] ?>', '<?= htmlspecialchars($domain['custom_domain']) ?>')">
                                    Check DNS Configuration
                                </button>
                                <span id="dns-status-<?= $domain['id'] ?>" class="status-indicator"></span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <p>No custom domains configured yet.</p>
            <?php endif; ?>
        </section>
    </div>

    <script>
    function checkDNS(id, domain) {
        const statusElement = document.getElementById(`dns-status-${id}`);
        statusElement.innerHTML = '<span class="checking">Checking...</span>';
        
        fetch(`/check_dns.php?domain=${encodeURIComponent(domain)}`)
            .then(response => response.json())
            .then(data => {
                statusElement.innerHTML = data.valid ? 
                    '<span class="valid">✓ DNS Configured</span>' : 
                    '<span class="invalid">✗ DNS Not Found</span>';
            })
            .catch(error => {
                statusElement.innerHTML = '<span class="invalid">Error checking DNS</span>';
            });
    }
    </script>
</body>
</html>
