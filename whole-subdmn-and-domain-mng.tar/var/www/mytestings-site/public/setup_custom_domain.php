<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method");
    }

    // Validate inputs
    $customDomain = strtolower(trim($_POST['custom_domain'] ?? ''));
    $subdomainId = (int)($_POST['subdomain_id'] ?? 0);
    $userId = $_SESSION['user_id'];

    // Validate domain format
    if (!preg_match('/^([a-z0-9-]+\.)+[a-z]{2,}$/i', $customDomain)) {
        throw new Exception("Invalid domain format");
    }

    // Verify subdomain ownership
    $stmt = $pdo->prepare("SELECT id, subdomain_name FROM subdomains WHERE id = ? AND user_id = ?");
    $stmt->execute([$subdomainId, $userId]);
    $subdomain = $stmt->fetch();
    
    if (!$subdomain) {
        throw new Exception("Invalid subdomain selection");
    }

    // Check existing domains
    $stmt = $pdo->prepare("SELECT id FROM custom_domains WHERE custom_domain = ?");
    $stmt->execute([$customDomain]);
    if ($stmt->fetch()) {
        throw new Exception("Domain already registered");
    }

    // Generate DNS target
    $dnsTarget = $subdomain['subdomain_name'] . '.mytestings.site';

    // Insert into database (UPDATED TO MATCH SCHEMA)
    $insertStmt = $pdo->prepare("
        INSERT INTO custom_domains 
        (user_id, subdomain_id, custom_domain, dns_target) 
        VALUES (?, ?, ?, ?)
    ");

    if (!$insertStmt->execute([$userId, $subdomainId, $customDomain, $dnsTarget])) {
        $error = $insertStmt->errorInfo();
        throw new Exception("Database error: " . $error[2]);
    }

    $_SESSION['success'] = "Custom domain added successfully!";

} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
}

header("Location: dashboard.php");
exit();
