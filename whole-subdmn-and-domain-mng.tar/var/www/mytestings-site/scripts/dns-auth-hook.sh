#!/bin/bash
DOMAIN="$CERTBOT_DOMAIN"
TOKEN="$CERTBOT_VALIDATION"

# Get verification token from database
VERIFICATION_TOKEN=$(mysql mydatabase -e "SELECT verification_token FROM custom_domains WHERE custom_domain='$DOMAIN'" -sN)

# Create DNS record (example for Cloudflare API)
curl -X POST "https://api.cloudflare.com/client/v4/zones/YOUR_ZONE_ID/dns_records" \
    -H "Authorization: Bearer YOUR_API_TOKEN" \
    -H "Content-Type: application/json" \
    --data '{"type":"TXT","name":"_acme-challenge.${DOMAIN}","content":"${TOKEN}","ttl":120}'

# Wait for DNS propagation
sleep 30
