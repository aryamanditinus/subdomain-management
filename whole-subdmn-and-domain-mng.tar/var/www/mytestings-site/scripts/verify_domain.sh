#!/bin/bash
DOMAIN=$1
SUBDOMAIN_TARGET=$2
SERVER_IP="13.201.4.222"

# Check A Record (extract only IP addresses)
A_RECORD=$(dig +short A "$DOMAIN" | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -n1)

if [ "$A_RECORD" != "$SERVER_IP" ]; then
    echo "A record failed: Expected '$SERVER_IP' got '$A_RECORD'"
    exit 1
fi

# Check CNAME Record (remove trailing dot)
CNAME_RECORD=$(dig +short CNAME "www.$DOMAIN" | sed 's/\.$//')
EXPECTED_CNAME="${SUBDOMAIN_TARGET}.mytestings.site"

if [[ "$CNAME_RECORD" != "$EXPECTED_CNAME" ]]; then
    echo "CNAME failed: Expected '$EXPECTED_CNAME' got '$CNAME_RECORD'"
    exit 1
fi

echo "verified"
exit 0
