#!/bin/bash
DOMAIN=$1
SSL_TYPE=$2

# Create verification directory structure
mkdir -p "/var/www/verifications/$DOMAIN/.well-known/acme-challenge"
chown -R www-data:www-data "/var/www/verifications/$DOMAIN"

if [ "$SSL_TYPE" == "letsencrypt" ]; then
    # Let's Encrypt Automatic Setup
    certbot certonly --webroot \
        -w "/var/www/verifications/$DOMAIN" \
        -d "$DOMAIN" \
        -d "www.$DOMAIN" \
        --non-interactive \
        --agree-tos \
        --email admin@mytestings.site
    
    # Update Apache config
    sed -i "s|{CERT_PATH}|/etc/letsencrypt/live/$DOMAIN/fullchain.pem|g" "/etc/apache2/sites-available/$DOMAIN.conf"
    sed -i "s|{KEY_PATH}|/etc/letsencrypt/live/$DOMAIN/privkey.pem|g" "/etc/apache2/sites-available/$DOMAIN.conf"
    
elif [ "$SSL_TYPE" == "custom" ]; then
    # Custom Certificate Handling
    CUSTOM_SSL_DIR="/etc/ssl/custom-certs/$DOMAIN"
    mkdir -p "$CUSTOM_SSL_DIR"
    
    # Move uploaded files
    mv /tmp/ssl_temp_cert.crt "$CUSTOM_SSL_DIR/fullchain.pem"
    mv /tmp/ssl_temp_key.key "$CUSTOM_SSL_DIR/privkey.pem"
    
    # Update Apache config
    sed -i "s|{CERT_PATH}|$CUSTOM_SSL_DIR/fullchain.pem|g" "/etc/apache2/sites-available/$DOMAIN.conf"
    sed -i "s|{KEY_PATH}|$CUSTOM_SSL_DIR/privkey.pem|g" "/etc/apache2/sites-available/$DOMAIN.conf"
    
    chown -R www-data:www-data "$CUSTOM_SSL_DIR"
fi

systemctl reload apache2
