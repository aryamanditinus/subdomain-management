#!/bin/bash
# Renew Let's Encrypt certificates
certbot renew --quiet

# Reload Apache for domains using Let's Encrypt
systemctl reload apache2

# For custom certificates, log expiration dates
find /etc/ssl/custom-certs/ -name fullchain.pem -exec openssl x509 -checkend 2592000 -noout -in {} \; -exec echo {} expiring soon \;
