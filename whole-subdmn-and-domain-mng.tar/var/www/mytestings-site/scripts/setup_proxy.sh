#!/bin/bash
DOMAIN=$1
TARGET_SUBDOMAIN=$2

# Create verification directory
mkdir -p "/var/www/verifications/$DOMAIN/.well-known/acme-challenge"
chown -R www-data:www-data "/var/www/verifications/$DOMAIN"

# Generate config from template
TEMPLATE="/etc/apache2/sites-available/custom-domain-template.conf"
CONFIG="/etc/apache2/sites-available/$DOMAIN.conf"

sed \
    -e "s/{DOMAIN}/$DOMAIN/g" \
    -e "s/{TARGET_SUBDOMAIN}/$TARGET_SUBDOMAIN/g" \
    "$TEMPLATE" > "$CONFIG"

# Enable site
a2ensite -q "$DOMAIN.conf"

# Get SSL certificate
certbot --apache -d "$DOMAIN" -d "www.$DOMAIN" \
    --non-interactive \
    --agree-tos \
    --email admin@mytestings.site \
    --keep-until-expiring \
    --redirect

systemctl reload apache2
echo "Configured $DOMAIN → $TARGET_SUBDOMAIN.mytestings.site"
