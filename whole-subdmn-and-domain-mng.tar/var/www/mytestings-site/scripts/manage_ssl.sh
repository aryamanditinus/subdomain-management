#!/bin/bash
DOMAIN=$1
SSL_TYPE=$2

# Let's Encrypt Paths
LE_CERT="/etc/letsencrypt/live/$DOMAIN/fullchain.pem"
LE_KEY="/etc/letsencrypt/live/$DOMAIN/privkey.pem"

# Custom SSL Paths
CUSTOM_DIR="/etc/ssl/custom-certs/$DOMAIN"
CUSTOM_CERT="$CUSTOM_DIR/fullchain.pem"
CUSTOM_KEY="$CUSTOM_DIR/privkey.pem"

CONFIG_FILE="/etc/apache2/sites-available/$DOMAIN.conf"

case $SSL_TYPE in
    letsencrypt)
        certbot --apache -d $DOMAIN -d www.$DOMAIN \
            --non-interactive \
            --agree-tos \
            --email admin@mytestings.site \
            --redirect \
            --keep-until-expiring
            
        sed -i "s|{CERT_PATH}|$LE_CERT|g" "$CONFIG_FILE"
        sed -i "s|{KEY_PATH}|$LE_KEY|g" "$CONFIG_FILE"
        ;;
        
    custom)
        mkdir -p "$CUSTOM_DIR"
        mv /tmp/ssl_temp.* "$CUSTOM_DIR/"
        
        sed -i "s|{CERT_PATH}|$CUSTOM_CERT|g" "$CONFIG_FILE"
        sed -i "s|{KEY_PATH}|$CUSTOM_KEY|g" "$CONFIG_FILE"
        ;;
esac

systemctl reload apache2
