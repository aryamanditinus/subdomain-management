<?php
// Use cloud metadata service or external check
$public_ip = '13.201.4.222'; // Static setting (recommended for stability)

// OR dynamic check (use only one method):
// $public_ip = file_get_contents('http://169.254.169.254/latest/meta-data/public-ipv4'); // AWS metadata
// $public_ip = trim(shell_exec('curl -s ifconfig.me'));

define('PUBLIC_IP', $public_ip);
