CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE subdomains (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subdomain_name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE custom_domains (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subdomain_id INT NOT NULL,
    custom_domain VARCHAR(255) NOT NULL UNIQUE,
    verification_token VARCHAR(64) NOT NULL,
    is_verified BOOLEAN DEFAULT 0,
    ssl_managed BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (subdomain_id) REFERENCES subdomains(id) ON DELETE CASCADE
);

ALTER TABLE custom_domains
ADD COLUMN dns_target VARCHAR(255),
ADD COLUMN ssl_enabled BOOLEAN DEFAULT 1;

ALTER TABLE custom_domains
ADD COLUMN ssl_type ENUM('letsencrypt', 'custom') DEFAULT 'letsencrypt',
ADD COLUMN ssl_cert_path VARCHAR(255),
ADD COLUMN ssl_key_path VARCHAR(255),
ADD COLUMN ssl_chain_path VARCHAR(255);


ALTER TABLE custom_domains 
DROP COLUMN verification_token,
ADD COLUMN dns_valid BOOLEAN DEFAULT 0;
